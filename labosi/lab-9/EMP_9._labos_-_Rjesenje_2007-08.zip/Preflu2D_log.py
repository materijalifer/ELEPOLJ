#! Preflu2D 9.30
loadProject('lab9.FLU')

closeProject()

exit()
